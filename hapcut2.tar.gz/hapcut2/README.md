HapCUT2: robust and accurate haplotype assembly for diverse sequencing technologies
======

New readme and documentation coming soon



to build:

 ```make ```

to run:

 ```./build/HAPCUT2 ```
